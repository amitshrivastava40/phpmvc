//
//  ViewController.swift
//  phpmvc
//
//  Created by TOPS on 7/6/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class ViewController: UIViewController,employeedelegate {

    @IBOutlet weak var lbl: UILabel!
   
    @IBOutlet weak var txtempname: UITextField!
    
    @IBOutlet weak var txtempadd: UITextField!
    
    
    @IBOutlet weak var txtempmob: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    

    @IBAction func btnclick(_ sender: Any) {
        
        let emp = employee(emp_id: 0, emp_name: txtempname.text!, emp_add: txtempadd.text!, emp_mob: txtempmob.text!);
        
        let obj = employeecontroller();
        
        obj.delgate = self;
        
        
        obj.insertempdata(empobj: emp)
        
        
        
        
        
    }
    
    func getresp(str:String)
    {
        
        DispatchQueue.main.async {
            self.lbl.text = str;

            
            
        }
        
        
       // print(str);
        
        
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

